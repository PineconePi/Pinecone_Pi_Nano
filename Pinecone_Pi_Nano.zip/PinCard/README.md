# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **PinCard** 

1.PinCard.jpg : PinCard For PineconePi Nano


# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **引脚示意卡** 

1.PinCard.jpg : 松果派引脚示意卡




# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **RTOS** 

1. RTX51-Chinese.pdf: RTX 51 RTOS (Chinese)
2. RTX51 FULL:RTX-51-FULL Install ZIP


# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **实时操作系统** 

1. RTX51-Chinese.pdf: RTX 51 RTOS (中文教程)
2. RTX51 FULL:RTX-51-FULL 安装包



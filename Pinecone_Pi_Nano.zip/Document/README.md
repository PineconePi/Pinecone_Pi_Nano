# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **List** 

1. Nano-Teaching documents.pdf：Teaching Documents（ENGLISH）
2. Nano入门指南.pdf:Teaching documents（Chinese)
 
 

# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **目录结构** 

1. Nano-Teaching documents.pdf：教学文档（英文）
2. Nano入门指南.pdf:教学文档（中文)

# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **List** 

1. STC8-English.pdf : Nano Chip datesheet
2. stc-isp.zip : Drive Programer +STC-ISP Download Software
3. PineconePinano.h ： Chip .H file



# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **文件说明** 

1. STC8A4K64S2A12.pdf : Nano板载芯片手册
2. stc-isp.zip : Nano驱动程序+STCISP下载程序+驱动安装说明
3. PineconePinano.h ： Nano 核心头文件


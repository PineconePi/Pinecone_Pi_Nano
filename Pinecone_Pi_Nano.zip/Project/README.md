# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **Project** 

1. 520 Day : a gift for grilfriend by PineconePi nano


# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **好玩的工程** 

1. 520 Day : 一个用松果派Nano制作的在5月20日送女朋友的礼物




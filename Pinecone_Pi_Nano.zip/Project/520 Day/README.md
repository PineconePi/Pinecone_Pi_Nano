# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **520 Day(a gift for girlfriend)** 

Author: XDD
Project Description: On May 20, 2019, I encountered very strange problems in reading and writing SDRAM. So I started making a gift for my girlfriend with Nano. (Even if I don't have a girlfriend)
Function 1: Press KEY2 continuously, and the digital tube shows "5", "2", "0" in turn.
Function 2: Continuously press KEY3, 8 LED's sixth, third, the first is lit in turn, corresponding to 5, 2, 0. Serial port 1 sends 520 in turn through baud rate 520.
Function 3: Press KEY4, serial port 1 sends "You are beautiful" through baud rate 520.“
Function 3: Press KEY5, serial port 1 sends "If you love me, please let me know!" through baud rate 520.“
 

# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **520 Day(一个给女朋友的礼物）** 

作者：xdd
项目说明：2019年5月20日，我在SDRAM读写上遇到了非常奇怪的问题。故开始制作用Nano制作一个礼物给女朋友。（即便我没女朋友）
功能1：连续按下KEY2，数码管依次显示“5”，”2“，”0“。
功能2：连续按下KEY3,8路LED的 第六个，第三个，第一个依次被点亮，对应 5，2，0。串口1通过波特率520 依次发送520.
功能3：按下KEY4，串口1通过波特率520，发送”You are beautiful!“
功能3：按下KEY5，串口1通过波特率520，发送”If you love me,please let me know!“

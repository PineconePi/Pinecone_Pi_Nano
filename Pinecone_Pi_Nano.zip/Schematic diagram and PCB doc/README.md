# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **Principle Diagram and Packaging Library** 

1. PineconePiNANO.zip : Nano Packaging Library（Altium Designer)
2. PineconePi_NANO.pdf : Nano Principle Diagram（Altium Designer)

# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **原理图与封装库** 

1. PineconePiNANO.zip : Nano封装库（Altium Designer)
2. PineconePi_NANO.pdf : Nano原理图（Altium Designer)




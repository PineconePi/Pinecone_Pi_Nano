/**
  ******************************************************************************
  * @file    mp3player.h
  * @author  PineconePi
  * @version V1.0.0
  * @date    20-December-2018
  * @brief  This article will be used for  driving  MP3 Player.
  * @License:GNU General Public License v3.0         
  ******************************************************************************
  * @attention
  *	include library/system/uart uart.c & uaet.h
  *
  *  
  * 
  * 
  * 
  * 
  *
  * 
  ******************************************************************************
	**/
# PineconePi Nano（[Click to enter the website](http://www.pineconepi.cn)，Support：support@pineconepi.cn)
###  **Example project** 

This project imports 51 library functions provided by pinecone pie to help beginners get started quickly.
 
 

# Pinecone_Pi_Nano（[点我进入官网](http://www.pineconepi.cn)，官方交流企鹅群：481227232)
###  **示例工程** 

这个工程导入了松果派提供的51库函数，帮助新手快速入门

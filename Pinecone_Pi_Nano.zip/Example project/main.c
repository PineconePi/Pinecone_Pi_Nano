#include "system.h"
#include  "adc.h"
#include  "delay.h"
#include  "eeprom.h"
#include  "exti.h"
#include  "gpio.h"
#include  "iic.h"
#include  "pca.h"
#include  "pwm.h"
#include  "timer.h"
#include  "uart.h"
#include  "watchdog.h"

#include  "digitaltube.h"
#include  "hc_sr04.h"
#include  "mp3player.h"
#include  "servo.h"
#include  "ws2812b.h"
void main()
{

}
